public class TurnCommand extends AbstractCommand{
    FlyingCar fc;


    TurnCommand(FlyingCar infc){
        fc = infc;
    }


    @Override
    public void execute(){
        fc.turn();
    }
}