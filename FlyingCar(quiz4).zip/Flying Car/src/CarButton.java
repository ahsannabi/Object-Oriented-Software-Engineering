public class CarButton{
    private String btnType="";

    private FlyingCar fc;

    //Constructor
    CarButton(FlyingCar fc){

        this.fc = fc;
    }


    public void setCommand(String btn ){
        btnType = btn;
    }


    public void btnClicked(){
    }

}