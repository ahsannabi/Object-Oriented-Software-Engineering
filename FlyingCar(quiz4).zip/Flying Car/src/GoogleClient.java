import java.util.ArrayList;

public class GoogleClient {

    public static void main(String[] args) {

        ArrayList<AbstractCommand> ac = new ArrayList<AbstractCommand>();

        for(AbstractCommand a : ac){
            a.execute();
        }

        FlyingCar fc = new FlyingCar();

        CarButton btn1 = new CarButton(fc);
        CarButton btn2 = new CarButton(fc);
        CarButton btn3 = new CarButton(fc);

        btn1.setCommand("Fly");
        btn2.setCommand("Land");
        btn1.setCommand("Turn");





        ArrayList<CarButton> faint = new ArrayList<CarButton>();

        for(CarButton c:faint){
            c.btnClicked();
        }



    }}
