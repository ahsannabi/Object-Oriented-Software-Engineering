import java.util.ArrayList;

public class FlyingCar {

    ArrayList<AbstractCommand> flyingCommandList;

    FlyingCar(){

    }



    void fly() {
        System.out.println("Flying");
    }

    void land() {
        System.out.println("Landing");
    }

    void turn() {
        System.out.println("Turning");
    }

}