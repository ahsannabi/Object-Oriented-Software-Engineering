public class Bill {

	private int billID;
	private int patientID;
	private int patientName;
	private int totalAmount;

}