public class Receptionist {

	private int id;
	private int name;
	private int cnic;
	private int phoneNumber;
	private int salary;

	public void checkRoomAvailability() {
		// TODO - implement Receptionist.checkRoomAvailability
		throw new UnsupportedOperationException();
	}

	public void bookRoom() {
		// TODO - implement Receptionist.bookRoom
		throw new UnsupportedOperationException();
	}

	public void printBill() {
		// TODO - implement Receptionist.printBill
		throw new UnsupportedOperationException();
	}

	public void maintainPatienDetails() {
		// TODO - implement Receptionist.maintainPatienDetails
		throw new UnsupportedOperationException();
	}

	public void setAppointment() {
		// TODO - implement Receptionist.setAppointment
		throw new UnsupportedOperationException();
	}

	public void informDoctor() {
		// TODO - implement Receptionist.informDoctor
		throw new UnsupportedOperationException();
	}

}