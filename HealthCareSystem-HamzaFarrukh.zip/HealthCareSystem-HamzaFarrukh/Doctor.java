public class Doctor {

	private int id;
	private int name;
	private int phoneNumber;
	private int age;
	private int cnic;
	private int roomNumber;
	private int specialization;
	private int experienceInYears;
	private int department;

}