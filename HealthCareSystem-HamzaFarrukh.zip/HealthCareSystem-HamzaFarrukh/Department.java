public class Department {

	private int id;
	private int name;
	private int headDoctor;

}