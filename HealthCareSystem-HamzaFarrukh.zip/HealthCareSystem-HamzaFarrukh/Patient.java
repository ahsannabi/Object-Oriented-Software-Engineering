public class Patient {

	private int id;
	private int name;
	private int phoneNumber;
	private int cnic;
	private int age;
	private int gender;
	private int medicalHistory;

	public void requestAppointment() {
		// TODO - implement Patient.requestAppointment
		throw new UnsupportedOperationException();
	}

	public void reSecheduleAppointment() {
		// TODO - implement Patient.reSecheduleAppointment
		throw new UnsupportedOperationException();
	}

	public void cancleAppointment() {
		// TODO - implement Patient.cancleAppointment
		throw new UnsupportedOperationException();
	}

	public void payBills() {
		// TODO - implement Patient.payBills
		throw new UnsupportedOperationException();
	}

}