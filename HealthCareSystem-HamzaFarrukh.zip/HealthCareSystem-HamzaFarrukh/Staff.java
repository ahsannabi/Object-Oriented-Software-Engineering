public class Staff {

	private int id;
	private int name;
	private int shift;
	private int salary;
	private int attribute;

}