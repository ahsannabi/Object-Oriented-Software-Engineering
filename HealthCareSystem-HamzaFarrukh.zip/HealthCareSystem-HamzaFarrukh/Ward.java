public class Ward extends Indoor {

	private int id;
	private int wardNumber;
	private int headNurse;
	private int numberOfBesds;

}