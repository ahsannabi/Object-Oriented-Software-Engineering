public class PrivateRoom extends Indoor {

	private int id;

}