public class Outdoor extends Patient {
}