public class Indoor extends Patient {

	private int allottedRoom;
	private int numberOfDaysRoomAllotted;

}