public class LandCommand extends AbstractCommand{
    FlyingCar fc;


    LandCommand(FlyingCar infc){
        fc = infc;
    }

    @Override
    public void execute(){
        fc.land();
    }
}