
import java.util.ArrayList;


public class CarButtons{
    private String btnType="";
    private ArrayList<AbstractCommand> cmdlist;
    private FlyingCar fc;

    //Constructor
    CarButtons(FlyingCar fc){

        this.fc = fc;
        cmdlist = new ArrayList<AbstractCommand>();
    }

    public void executeCommandList()
    {
        for(AbstractCommand cmd : cmdlist)
            cmd.execute();
    
    }
    public void setCommand(String btn ){
        btnType = btn;
        
        if(null!=btnType)
            switch (btnType) {
            case "Fly":
                AbstractCommand cmdfly = new FlyCommand(fc);
                cmdlist.add(cmdfly);
                break;
            case "Turn":
                AbstractCommand cmdturn = new TurnCommand(fc);
                cmdlist.add(cmdturn);
                break;
            case "Land":
                AbstractCommand cmdland = new LandCommand(fc);
                cmdlist.add(cmdland);
                break;
            default:
                break;
        }
    }


    public void btnClicked(){
        System.out.println("Button "+btnType+" clicked");
        setCommand(btnType);
    }

}