import java.util.ArrayList;

public class GoogleClient {

    public static void main(String[] args) {

        FlyingCar fc = new FlyingCar();

        CarButtons btns = new CarButtons(fc);

        btns.setCommand("Fly");
        btns.setCommand("Turn");
        btns.setCommand("Turn");
        btns.setCommand("Land");
        
        btns.executeCommandList();
              
    }
}
