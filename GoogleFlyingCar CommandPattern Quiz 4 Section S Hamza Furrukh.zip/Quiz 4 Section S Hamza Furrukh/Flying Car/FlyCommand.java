public class FlyCommand extends AbstractCommand{

    FlyingCar fc;



    FlyCommand(FlyingCar infc){
        fc = infc;
    }


    @Override
    public void execute(){
        fc.fly();
    }
}