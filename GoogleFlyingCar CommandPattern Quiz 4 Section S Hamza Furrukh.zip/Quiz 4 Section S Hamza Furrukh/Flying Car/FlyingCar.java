public class FlyingCar {

    FlyingCar(){

    }

    void fly() {
        System.out.println("Flying");
    }

    void land() {
        System.out.println("Landing");
    }

    void turn() {
        System.out.println("Turning");
    }

}