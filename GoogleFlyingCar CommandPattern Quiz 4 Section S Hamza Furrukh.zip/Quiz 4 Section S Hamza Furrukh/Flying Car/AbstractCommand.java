public class AbstractCommand{


    AbstractCommand(){

    }

    public void execute(){

    }
}