/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hariscommandpatt;

/**
 *
 * @author John
 */

    public class LandCommand extends AbstractCommand{
        FlyingCar infc;
        LandCommand(FlyingCar fc){
            infc=fc;
        }
        @Override
        public void execute(){
            infc.land();
        }
    }


