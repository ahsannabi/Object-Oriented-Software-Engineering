/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hariscommandpatt;





/**
 *
 * @author John
 */
public class HarisCommandPatt {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
            FlyingCar fcar=new FlyingCar();
            
            LandCommand lc= new LandCommand(fcar);
            CarButton btnland= new CarButton(lc);
            btnland.setCommand(lc);
            btnland.btnClicked();
            
            FlyCommand fc= new FlyCommand(fcar);
            CarButton btnfly= new CarButton(fc);
            btnfly.setCommand(fc);	
            btnfly.btnClicked();
            
            TurnCommand tc= new TurnCommand(fcar);
            CarButton btnturn= new CarButton(tc);
            btnturn.setCommand(tc);	
            btnturn.btnClicked();
        
    
}}
