/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hariscommandpatt;

/**
 *
 * @author John
 */

    public class CarButton{
        AbstractCommand cmdtype;
        CarButton(AbstractCommand btn){
            
            cmdtype=btn;
        }
        public void setCommand(AbstractCommand btntype){
            this.cmdtype=btntype;
        }
     public void btnClicked(){
       this.cmdtype.execute();
        }

    }



